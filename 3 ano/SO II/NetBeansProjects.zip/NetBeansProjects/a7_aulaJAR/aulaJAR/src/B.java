package so2;

public class B {
    int valor;
    
    public B(int x) {
        this.valor= x;
    }
    
    public int getValue() {
        return valor;
    }
    
}