package aularminb;

/**
 *
 * @author jsaias
 */
public class AulaRMInb {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {

    }
    
}
