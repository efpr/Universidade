java -classpath build/classes/ so2.EchoServer 9000
