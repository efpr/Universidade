java -classpath build/classes/ so2.EchoClient localhost 9000 $1
